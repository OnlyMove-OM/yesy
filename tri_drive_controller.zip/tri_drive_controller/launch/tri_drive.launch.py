from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from pathlib import Path


def generate_launch_description():
    pkg_share = Path(get_package_share_directory('tri_drive_controller'))
    params_file = pkg_share / 'config' / 'tri_drive.yaml'

    return LaunchDescription([
        Node(
            package='tri_drive_controller',
            executable='tri_drive_node',
            name='tri_drive_controller',
            output='screen',
            parameters=[str(params_file)],
        )
    ])

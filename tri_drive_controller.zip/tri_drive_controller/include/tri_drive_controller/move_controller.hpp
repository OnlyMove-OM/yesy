#pragma once

#include "titan.h"

#include <array>
#include <chrono>
#include <cstdint>
#include <memory>

namespace tri_drive_controller
{

struct MotorCommand
{
  double left{0.0};
  double right{0.0};
  double rear{0.0};
};

class MoveController
{
public:
  MoveController(
    uint8_t can_id,
    uint16_t motor_frequency,
    float distance_per_tick,
    int left_motor,
    int right_motor,
    int rear_motor,
    double sign_left,
    double sign_right,
    double sign_rear,
    double max_output,
    double linear_wpi_scale,
    double angular_wpi_scale);

  ~MoveController();

  MoveController(const MoveController &) = delete;
  MoveController & operator=(const MoveController &) = delete;

  void enable(bool enabled);
  bool enabled() const;

  void stop();

  // WPI Move::NH equivalent. Arguments are WPI-scale x/y/w values.
  MotorCommand mix_nh_wpi(double x, double y, double w) const;

  // ROS Twist normalized interface. linear.x/y and angular.z are scaled to WPI units.
  MotorCommand mix_cmd_vel(double linear_x, double linear_y, double angular_z) const;

  void write(const MotorCommand & command);
  void write_cmd_vel(double linear_x, double linear_y, double angular_z);

private:
  static double clamp(double value, double min_value, double max_value);
  static double approach(double current, double target, double step);

  void raw_set(double left, double right, double rear);

  studica_driver::Titan titan_;

  const int left_motor_;
  const int right_motor_;
  const int rear_motor_;

  const double sign_left_;
  const double sign_right_;
  const double sign_rear_;
  const double max_output_;
  const double linear_wpi_scale_;
  const double angular_wpi_scale_;

  bool enabled_{false};
};

}  // namespace tri_drive_controller

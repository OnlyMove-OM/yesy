#include "tri_drive_controller/move_controller.hpp"

#include <memory>
#include <string>

#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32_multi_array.hpp"
#include "std_srvs/srv/set_bool.hpp"
#include "std_srvs/srv/trigger.hpp"

namespace tri_drive_controller
{

class TriDriveNode : public rclcpp::Node
{
public:
  TriDriveNode()
  : Node("tri_drive_controller")
  {
    const int can_id = declare_parameter<int>("can_id", 42);
    const int motor_frequency = declare_parameter<int>("motor_frequency", 15600);
    const double distance_per_tick = declare_parameter<double>(
      "distance_per_tick", (2.0 * 3.14159265358979323846 * 0.051) / 1464.0);

    const int left_motor = declare_parameter<int>("left_motor", 0);
    const int right_motor = declare_parameter<int>("right_motor", 1);
    const int rear_motor = declare_parameter<int>("rear_motor", 2);

    const double sign_left = declare_parameter<double>("sign_left", 1.0);
    const double sign_right = declare_parameter<double>("sign_right", 1.0);
    const double sign_rear = declare_parameter<double>("sign_rear", 1.0);

    const double max_output = declare_parameter<double>("max_output", 0.25);
    const double linear_wpi_scale = declare_parameter<double>("linear_wpi_scale", 534.0);
    const double angular_wpi_scale = declare_parameter<double>("angular_wpi_scale", 140.0);

    cmd_vel_timeout_sec_ = declare_parameter<double>("cmd_vel_timeout_sec", 0.35);
    const int control_period_ms = declare_parameter<int>("control_period_ms", 20);

    controller_ = std::make_unique<MoveController>(
      static_cast<uint8_t>(can_id),
      static_cast<uint16_t>(motor_frequency),
      static_cast<float>(distance_per_tick),
      left_motor,
      right_motor,
      rear_motor,
      sign_left,
      sign_right,
      sign_rear,
      max_output,
      linear_wpi_scale,
      angular_wpi_scale);

    motor_debug_pub_ = create_publisher<std_msgs::msg::Float32MultiArray>("motor_speeds", 10);

    cmd_vel_sub_ = create_subscription<geometry_msgs::msg::Twist>(
      "cmd_vel",
      rclcpp::QoS(10),
      [this](const geometry_msgs::msg::Twist::SharedPtr msg) {
        target_x_ = msg->linear.x;
        target_y_ = msg->linear.y;
        target_w_ = msg->angular.z;
        last_cmd_time_ = now();
      });

    stop_srv_ = create_service<std_srvs::srv::Trigger>(
      "stop",
      [this](
        const std::shared_ptr<std_srvs::srv::Trigger::Request>,
        std::shared_ptr<std_srvs::srv::Trigger::Response> response) {
        target_x_ = 0.0;
        target_y_ = 0.0;
        target_w_ = 0.0;
        controller_->stop();
        response->success = true;
        response->message = "stopped all Titan outputs";
      });

    enable_srv_ = create_service<std_srvs::srv::SetBool>(
      "enable",
      [this](
        const std::shared_ptr<std_srvs::srv::SetBool::Request> request,
        std::shared_ptr<std_srvs::srv::SetBool::Response> response) {
        controller_->enable(request->data);
        response->success = true;
        response->message = request->data ? "Titan enabled" : "Titan disabled";
      });

    last_cmd_time_ = now();

    control_timer_ = create_wall_timer(
      std::chrono::milliseconds(control_period_ms),
      [this]() { control_loop(); });

    RCLCPP_INFO(
      get_logger(),
      "tri_drive_controller ready. cmd_vel linear.x/y and angular.z are normalized [-1, 1].");
  }

  ~TriDriveNode() override
  {
    if (controller_) {
      controller_->stop();
      controller_->enable(false);
    }
  }

private:
  void control_loop()
  {
    const double age = (now() - last_cmd_time_).seconds();
    const bool timed_out = age > cmd_vel_timeout_sec_;

    const double x = timed_out ? 0.0 : target_x_;
    const double y = timed_out ? 0.0 : target_y_;
    const double w = timed_out ? 0.0 : target_w_;

    const MotorCommand command = controller_->mix_cmd_vel(x, y, w);
    controller_->write(command);

    std_msgs::msg::Float32MultiArray debug;
    debug.data = {
      static_cast<float>(command.left),
      static_cast<float>(command.right),
      static_cast<float>(command.rear)};
    motor_debug_pub_->publish(debug);
  }

  std::unique_ptr<MoveController> controller_;

  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
  rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr motor_debug_pub_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr stop_srv_;
  rclcpp::Service<std_srvs::srv::SetBool>::SharedPtr enable_srv_;
  rclcpp::TimerBase::SharedPtr control_timer_;

  rclcpp::Time last_cmd_time_;
  double cmd_vel_timeout_sec_{0.35};

  double target_x_{0.0};
  double target_y_{0.0};
  double target_w_{0.0};
};

}  // namespace tri_drive_controller

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<tri_drive_controller::TriDriveNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}

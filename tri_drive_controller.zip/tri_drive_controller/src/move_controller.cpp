#include "tri_drive_controller/move_controller.hpp"

#include <algorithm>
#include <cmath>
#include <thread>

namespace tri_drive_controller
{
namespace
{
constexpr double kSqrt3Over2 = 0.8660254037844386;
constexpr double kWpiMax = 534.0;
constexpr double kWpiTurnGain = 3.4;
}  // namespace

MoveController::MoveController(
  uint8_t can_id,
  uint16_t motor_frequency,
  float distance_per_tick,
  int left_motor,
  int right_motor,
  int rear_motor,
  double sign_left,
  double sign_right,
  double sign_rear,
  double max_output,
  double linear_wpi_scale,
  double angular_wpi_scale)
: titan_(can_id, motor_frequency, distance_per_tick),
  left_motor_(left_motor),
  right_motor_(right_motor),
  rear_motor_(rear_motor),
  sign_left_(sign_left),
  sign_right_(sign_right),
  sign_rear_(sign_rear),
  max_output_(std::abs(max_output)),
  linear_wpi_scale_(linear_wpi_scale),
  angular_wpi_scale_(angular_wpi_scale)
{
  // Give VMX/Titan driver threads time to settle before enabling motor output.
  std::this_thread::sleep_for(std::chrono::milliseconds(1000));
  enable(true);
  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  stop();
}

MoveController::~MoveController()
{
  stop();
  std::this_thread::sleep_for(std::chrono::milliseconds(100));
  enable(false);
}

void MoveController::enable(bool enabled)
{
  enabled_ = enabled;
  titan_.Enable(enabled);
  if (!enabled) {
    raw_set(0.0, 0.0, 0.0);
  }
}

bool MoveController::enabled() const
{
  return enabled_;
}

void MoveController::stop()
{
  raw_set(0.0, 0.0, 0.0);
}

MotorCommand MoveController::mix_nh_wpi(double x, double y, double w) const
{
  // WPI Move::NH formula:
  //   sp0 =  x * sqrt(3)/2 + y/2 + w*3.4
  //   sp1 = -x * sqrt(3)/2 + y/2 + w*3.4
  //   sp2 = -y              + w*3.4
  // Mapping confirmed on the robot:
  //   Titan 0 = left, Titan 1 = right, Titan 2 = rear.
  double left = x * kSqrt3Over2 + y * 0.5 + w * kWpiTurnGain;
  double right = -x * kSqrt3Over2 + y * 0.5 + w * kWpiTurnGain;
  double rear = -y + w * kWpiTurnGain;

  const double max_abs = std::max({std::abs(left), std::abs(right), std::abs(rear), kWpiMax});
  if (max_abs > kWpiMax) {
    const double scale = kWpiMax / max_abs;
    left *= scale;
    right *= scale;
    rear *= scale;
  }

  // WPI Trans(-534, 534, -1, 1, sp) is equivalent to sp / 534.
  left = (left / kWpiMax) * sign_left_;
  right = (right / kWpiMax) * sign_right_;
  rear = (rear / kWpiMax) * sign_rear_;

  return MotorCommand{
    clamp(left, -max_output_, max_output_),
    clamp(right, -max_output_, max_output_),
    clamp(rear, -max_output_, max_output_)};
}

MotorCommand MoveController::mix_cmd_vel(double linear_x, double linear_y, double angular_z) const
{
  const double x = clamp(linear_x, -1.0, 1.0) * linear_wpi_scale_;
  const double y = clamp(linear_y, -1.0, 1.0) * linear_wpi_scale_;
  const double w = clamp(angular_z, -1.0, 1.0) * angular_wpi_scale_;
  return mix_nh_wpi(x, y, w);
}

void MoveController::write(const MotorCommand & command)
{
  if (!enabled_) {
    raw_set(0.0, 0.0, 0.0);
    return;
  }

  raw_set(
    clamp(command.left, -max_output_, max_output_),
    clamp(command.right, -max_output_, max_output_),
    clamp(command.rear, -max_output_, max_output_));
}

void MoveController::write_cmd_vel(double linear_x, double linear_y, double angular_z)
{
  write(mix_cmd_vel(linear_x, linear_y, angular_z));
}

double MoveController::clamp(double value, double min_value, double max_value)
{
  return std::max(min_value, std::min(max_value, value));
}

double MoveController::approach(double current, double target, double step)
{
  if (target > current + step) {
    return current + step;
  }
  if (target < current - step) {
    return current - step;
  }
  return target;
}

void MoveController::raw_set(double left, double right, double rear)
{
  titan_.SetSpeed(static_cast<uint8_t>(left_motor_), left);
  titan_.SetSpeed(static_cast<uint8_t>(right_motor_), right);
  titan_.SetSpeed(static_cast<uint8_t>(rear_motor_), rear);

  // Titan 3 is unused on this robot; force it off whenever we send motor output.
  for (int motor = 0; motor < 4; ++motor) {
    if (motor != left_motor_ && motor != right_motor_ && motor != rear_motor_) {
      titan_.SetSpeed(static_cast<uint8_t>(motor), 0.0);
    }
  }
}

}  // namespace tri_drive_controller

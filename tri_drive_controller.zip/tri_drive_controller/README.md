# tri_drive_controller

Clean ROS2 controller for the 3-wheel triangular omni/kiwi robot using VMX + Studica Titan Quad.

Confirmed hardware mapping:

- Titan CAN ID: `42`
- Left wheel: Titan motor `0`
- Right wheel: Titan motor `1`
- Rear wheel: Titan motor `2`
- Titan motor `3`: unused

The controller uses the WPI `Move::NH()` kinematic mixer:

```cpp
sp0 =  x * sqrt(3)/2 + y/2 + w*3.4;
sp1 = -x * sqrt(3)/2 + y/2 + w*3.4;
sp2 = -y              + w*3.4;
```

ROS2 `/cmd_vel` mapping:

- `linear.x`: forward/backward
- `linear.y`: left/right
- `angular.z`: rotate

Inputs are treated as normalized speeds in `[-1.0, 1.0]`. Start around `0.10` to `0.20`.

## Build

Copy this package to your workspace:

```bash
cd /home/vmx/ROS2
cp -r /path/to/tri_drive_controller src/
colcon build --symlink-install --packages-select tri_drive_controller
source /opt/ros/humble/setup.bash
source install/setup.bash
```

If runtime cannot find `libstudica_drivers.so`, either use `sudo env LD_LIBRARY_PATH=...` or register the libraries:

```bash
echo "/usr/local/lib/studica_drivers" | sudo tee /etc/ld.so.conf.d/studica_drivers.conf
echo "/usr/local/lib/vmxpi" | sudo tee -a /etc/ld.so.conf.d/studica_drivers.conf
sudo ldconfig
```

## Run

Stop other VMX/Studica processes first:

```bash
sudo pkill -9 -f manual_composition
sudo pkill -9 -f studica_launch
sudo pkill -9 -f velocity_smoother
sudo pkill -9 -f lifecycle_manager
```

Launch the controller as root because VMX hardware access requires it:

```bash
sudo -i
cd /home/vmx/ROS2
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch tri_drive_controller tri_drive.launch.py
```

In another terminal:

```bash
cd /home/vmx/ROS2
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run tri_drive_controller keyboard_drive.py
```

## Manual command tests

Forward:

```bash
ros2 topic pub --once /cmd_vel geometry_msgs/msg/Twist \
"{linear: {x: 0.15, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
```

Backward:

```bash
ros2 topic pub --once /cmd_vel geometry_msgs/msg/Twist \
"{linear: {x: -0.15, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}"
```

Rotate:

```bash
ros2 topic pub --once /cmd_vel geometry_msgs/msg/Twist \
"{linear: {x: 0.0, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.15}}"
```

Stop service:

```bash
ros2 service call /tri_drive_controller/stop std_srvs/srv/Trigger "{}"
```

Enable/disable:

```bash
ros2 service call /tri_drive_controller/enable std_srvs/srv/SetBool "{data: false}"
ros2 service call /tri_drive_controller/enable std_srvs/srv/SetBool "{data: true}"
```

## Tuning

Edit `config/tri_drive.yaml`:

- If forward/backward is reversed: set `sign_left: -1.0` and `sign_right: -1.0`.
- If rear/side motion is reversed: flip `sign_rear`.
- Keep `max_output` low until tuning is done.

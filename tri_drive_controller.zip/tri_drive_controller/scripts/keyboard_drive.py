#!/usr/bin/env python3
import sys
import termios
import tty
import select

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

HELP = """
Keyboard drive for tri_drive_controller

  w/s : forward/backward
  a/d : left/right strafe
  q/e : turn counter-clockwise/clockwise
  x   : stop
  +/- : change speed
  Ctrl+C to quit
"""


def get_key(timeout=0.05):
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        rlist, _, _ = select.select([sys.stdin], [], [], timeout)
        if rlist:
            return sys.stdin.read(1)
        return ''
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


class KeyboardDrive(Node):
    def __init__(self):
        super().__init__('tri_keyboard_drive')
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.speed = 0.15
        self.turn = 0.15
        self.timer = self.create_timer(0.05, self.loop)
        self.current = Twist()
        print(HELP)

    def loop(self):
        key = get_key(0.001)
        msg = Twist()

        if key == 'w':
            msg.linear.x = self.speed
        elif key == 's':
            msg.linear.x = -self.speed
        elif key == 'a':
            msg.linear.y = self.speed
        elif key == 'd':
            msg.linear.y = -self.speed
        elif key == 'q':
            msg.angular.z = -self.turn
        elif key == 'e':
            msg.angular.z = self.turn
        elif key == 'x':
            msg = Twist()
        elif key == '+':
            self.speed = min(0.5, self.speed + 0.05)
            self.turn = min(0.5, self.turn + 0.05)
            print(f'speed={self.speed:.2f}, turn={self.turn:.2f}')
            msg = self.current
        elif key == '-':
            self.speed = max(0.05, self.speed - 0.05)
            self.turn = max(0.05, self.turn - 0.05)
            print(f'speed={self.speed:.2f}, turn={self.turn:.2f}')
            msg = self.current
        elif key == '\x03':
            raise KeyboardInterrupt
        else:
            # Hold last command only while key is being pressed; no key means stop.
            msg = Twist()

        self.current = msg
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = KeyboardDrive()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        stop = Twist()
        for _ in range(5):
            node.pub.publish(stop)
        print('\nStopped')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
